import * as authService from './auth.service.js'
import ApiRes from '../../common/utils/api-respons.js'


const register = async(req, res, next) => {
    try{
        const user  = await authService.register(req.body);
        ApiRes.created(res, "Registration succes", user)
    }catch(err){
        
        console.error("eror came", err.message)
    }
}

const verifyEmail = async(req,res, next) => {
    try{
        const rest = await authService.verifyEmail(req.body)
        console.log(rest)
    }catch(err){
        console.log(err.message)
    }
}

const login = async (req, res) => {
    const {user, accessToken, refreshToken} = await authService.login(req.body)
    res.cookie("refreshToken", refreshToken, {
        httpOnly : true,
        secure : process.env.NODE_ENV === 'production',
        maxAge : 7 * 24 * 60 * 60 * 1000,
    })
    res.cookie("accessToken", accessToken, {
        httpOnly : true,
        secure : process.env.NODE_ENV === 'production',
        maxAge : 15 * 60 * 1000,
    })

    ApiRes.ok(res, "login Successful", {user})
}

const logOut = async (req, res) => {
    const user = await authService.logOut(req.user.id);
    res.clearCookie("refreshToken");
    ApiRes.ok(res, "LogOut Success");
}


const getMe = async (req, res) => {
    const user = await authService.getMe(req.user.id);
    ApiRes.ok(res, "userProfile ", user);
}

export {
    register,
    verifyEmail,
    login,
    logOut,
    getMe,
}