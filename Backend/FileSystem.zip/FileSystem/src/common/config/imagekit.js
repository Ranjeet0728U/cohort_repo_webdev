import ImageKit from "@imagekit/nodejs"

const imagekit = new ImageKit({
    publicKey:process.env.IMAGEKIT_PUBLIC_KEY,
    privateKey:process.env.IMAGEKT_PRIVATE_KEY,
    urlEndpoint:process.env.IMAGEKIT_ENDPOINT
})

export default imagekit;